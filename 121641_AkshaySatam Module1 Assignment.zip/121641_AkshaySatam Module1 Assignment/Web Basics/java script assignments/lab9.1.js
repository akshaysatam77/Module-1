

function test()
{
	var re= document.exprsn.expr1.value;
var str= document.exprsn.subject1.value;
var re2= new RegExp(re);

var result= re2.test(str);

if(result == true)
{
	alert('Successful match');
}

else
{
	alert('Unsuccessful match');
}
}

function show()
{
	var re3= document.exprsn.expr1.value;
	var str2= document.exprsn.subject1.value;
	var re4= new RegExp(re3);

	var result2 = re4.exec(str2);
	var ind = str2.match(re4).index;
	alert('Match found: at position: '+ind+" , : "+result2);
}
